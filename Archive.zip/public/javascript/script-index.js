var my_div = document.getElementById('stressed')

var addrainbow = function () {
    var my_div = document.getElementById('stressed');
    my_div.classList.add("rainbow-11");
}

my_div.addEventListener('click', addrainbow)

var my_div = document.getElementById('empowered')

var addrainbow = function () {
    var my_div = document.getElementById('empowered');
    my_div.classList.add("rainbow-11");
}

my_div.addEventListener('click', addrainbow)



var my_div = document.getElementById('angry')

var addrainbow = function () {
    var my_div = document.getElementById('angry');
    my_div.classList.add("rainbow-15");
}

my_div.addEventListener('click', addrainbow)

var my_div = document.getElementById('joyful')

var addrainbow = function () {
    var my_div = document.getElementById('joyful');
    my_div.classList.add("rainbow-15");
}

my_div.addEventListener('click', addrainbow)

var my_div = document.getElementById('indifferent')

var addrainbow = function () {
    var my_div = document.getElementById('indifferent');
    my_div.classList.add("rainbow-15");
}

my_div.addEventListener('click', addrainbow)

var my_div = document.getElementById('shameful')

var addrainbow = function () {
    var my_div = document.getElementById('shameful');
    my_div.classList.add("rainbow-15");
}

my_div.addEventListener('click', addrainbow)

var my_div = document.getElementById('calm')

var addrainbow = function () {
    var my_div = document.getElementById('calm');
    my_div.classList.add("rainbow-15");
}

my_div.addEventListener('click', addrainbow)

var my_div = document.getElementById('sad')

var addrainbow = function () {
    var my_div = document.getElementById('sad');
    my_div.classList.add("rainbow-15");
}

my_div.addEventListener('click', addrainbow)

var my_div = document.getElementById('anxious')

var addrainbow = function () {
    var my_div = document.getElementById('anxious');
    my_div.classList.add("rainbow-15");
}

my_div.addEventListener('click', addrainbow)


var my_div = document.getElementById('frustrated')

var addrainbow = function () {
    var my_div = document.getElementById('frustrated');
    my_div.classList.add("rainbow-15");
}

document.getElementById('frustrated').addEventListener('click', addrainbow);

var my_div = document.getElementById('bored')

var addrainbow = function () {
    var my_div = document.getElementById('bored');
    my_div.classList.add("rainbow-15");
}

my_div.addEventListener('click', addrainbow)

var addrainbow = function () {
    var my_div2 = document.getElementById('afraid');
    my_div2.classList.add("rainbow-11");
}

document.getElementById('afraid').addEventListener('click', addrainbow);
